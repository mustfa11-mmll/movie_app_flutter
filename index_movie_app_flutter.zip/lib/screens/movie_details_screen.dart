import 'package:flutter/material.dart';
import '../models/movie.dart';

class MovieDetailsScreen extends StatelessWidget {
  final Movie movie;

  const MovieDetailsScreen({required this.movie});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(movie.title)),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            Image.network(movie.image),
            SizedBox(height: 20),
            Text(movie.title, style: TextStyle(fontSize: 24)),
            SizedBox(height: 10),
            Text("التقييم: ${movie.rating}", style: TextStyle(fontSize: 18)),
            SizedBox(height: 20),
            Text("وصف مختصر للفيلم هنا...", style: TextStyle(fontSize: 16)),
          ],
        ),
      ),
    );
  }
}