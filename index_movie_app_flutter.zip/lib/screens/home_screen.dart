import 'package:flutter/material.dart';
import '../widgets/movie_card.dart';
import '../models/movie.dart';
import 'movie_details_screen.dart';

class HomeScreen extends StatelessWidget {
  final List<Movie> movies = [
    Movie(title: 'Inception', rating: 8.8, image: 'https://image.tmdb.org/t/p/w500/qmDpIHrmpJINaRKAfWQfftjCdyi.jpg'),
    Movie(title: 'Interstellar', rating: 8.6, image: 'https://image.tmdb.org/t/p/w500/rAiYTfKGqDCRIIqo664sY9XZIvQ.jpg'),
    Movie(title: 'The Matrix', rating: 8.7, image: 'https://image.tmdb.org/t/p/w500/f89U3ADr1oiB1s9GkdPOEpXUk5H.jpg'),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("أفلام اليوم")),
      body: GridView.builder(
        padding: EdgeInsets.all(12),
        gridDelegate:
            SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12),
        itemCount: movies.length,
        itemBuilder: (context, index) {
          return GestureDetector(
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => MovieDetailsScreen(movie: movies[index]),
              ),
            ),
            child: MovieCard(movie: movies[index]),
          );
        },
      ),
    );
  }
}